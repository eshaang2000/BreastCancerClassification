Hi

I have put everything in a folder so it is easy to access. 
To run this you migth have to install a few libraries. I can demonstrate the porject if this is not feasible.

You can either put in your own test inputs or just use my test matrix.

To run the program you have to use a Python development environment or use the terminal. Just hit run if you have an environment or run the following command in the terminal.

python main.py

I have included a few test cases names - test4.txt, test5.txt, test3.txt. You can also get you tests but make sure you strip the first 2 attributes. That contain results so it does not make sense to include that.

I can also demonstrate the project please let me know. 
